<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width-device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <h1>Formulario</h1>
    <form action="Ejercicio_1_Main.php" method="get">
        <label for="nombre">Nombre:</label>
        <input type="text" name="Nombre" id="Nombre">
    
        <br>
        <br>

        <label for="apellido">Apellido:</label>
        <input type="text" name="Apellido" id="Apellido">
    
        <br>
        <br>

        <label for="edad">Edad:</label>
        <input type="text" name="Edad" id="Edad">
    
        <br>
        <br>

        <label for="email">Email:</label>
        <input type="text" name="Email" id="Email">
    
        <br>
        <br>

        <input type="submit" value="Enviar">
    </form>

</body>
</html>