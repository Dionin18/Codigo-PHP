<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width-device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <h1>Formulario</h1>
    <form action="Ejercicio_5.5.php" method="get">
        Ingrese el nombre del alumno:<br><input type="text" name="nombre" id="nombre"><br>
        <label for="numeros">Ingrese las notas del alumno:</label><br>
        Nota 1:<br><input type="number" name="nota_1" id="nota_1"><br>
        Nota 2:<br><input type="number" name="nota_2" id="nota_2"><br>
        Nota 3:<br><input type="number" name="nota_3" id="nota_3"><br>
        Nota 4:<br><input type="number" name="nota_4" id="nota_4"><br>
        Nota 5:<br><input type="number" name="nota_5" id="nota_5"><br>
        <br>

        <input type="submit" value="Enviar">
    </form>

</body>
</html>