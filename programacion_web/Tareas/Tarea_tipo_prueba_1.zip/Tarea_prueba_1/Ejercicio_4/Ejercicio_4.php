<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width-device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <h1>Formulario</h1>
    <form action="Ejercicio_4.4.php" method="get">
        <label for="numeros">Ingrese los datos del estudiante:</label><br>
        Nombre:
        <br><input type="text" name="nombre" id="nombre"><br>
        Apellido:
        <br><input type="text" name="apellido" id="apellido"><br>
        Edad:
        <br><input type="number" name="edad" id="edad"><br>
        Carrera:
        <br><input type="text" name="carrera" id="carrera"><br>
        

        <input type="submit" value="Enviar">
    </form>

</body>
</html>