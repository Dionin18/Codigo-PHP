<?php

$clp = $_GET["Clp"];

echo $clp . " CLP equivalen a " . $clp / 931 . " Dolar(es)";