<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width-device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <h1>Formulario</h1>
    <form action="Ejercicio_2.2.php" method="get">
        <label for="clp">Ingrese pesos a convertir (1 Dolar = 931 CLP):</label><br>
        <input type="number" name="Clp" id="Clp">
    
        <br>

        <input type="submit" value="Enviar">
    </form>

</body>
</html>