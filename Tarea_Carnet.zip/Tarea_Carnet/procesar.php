<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body>


<?php

function guardar($conexion, $nombre, $apellidoP, $apellidoM, $rut, $lugar, $profesion, $fecha, $sexo, $discap, $donante, $foto, $nacionalidad){
    $sql = "INSERT INTO personas (nombre, apellidoP, apellidoM, rut, lugar, profesion, fecha, sexo, discap, donante, foto, nacionalidad) VALUES ('$nombre', '$apellidoP', '$apellidoM', '$rut', '$lugar', '$profesion', '$fecha', '$sexo', '$discap', '$donante', '$foto', '$nacionalidad')";

    // ejecutar la consulta
    
    $resultado = mysqli_query($conexion, $sql);
    
    if($resultado){
        echo "<br>Se inserto correctamente el alumno.<br>";
        return True;
    }else{
        echo "<br>Error al insertar el alumno.<br>";
        echo "<br>La consulta $sql - Fallo: " + mysqli_error($conexion);
        return False;
    }
}

function valida_rut($rut)
{
    $rut = preg_replace('/[^k0-9]/i', '', $rut);
    $dv  = substr($rut, -1);
    $numero = substr($rut, 0, strlen($rut)-1);
    $i = 2;
    $suma = 0;
    foreach(array_reverse(str_split($numero)) as $v)
    {
        if($i==8)
            $i = 2;

        $suma += $v * $i;
        ++$i;
    }

    $dvr = 11 - ($suma % 11);
    
    if($dvr == 11)
        $dvr = 0;
    if($dvr == 10)
        $dvr = 'K';

    if($dvr == strtoupper($dv))
        return true;
    else
        return false;
}


//datos de conexion a la base de datos

$db_host = "localhost";
$db_name = "registro";
$db_user = "root";
$db_pass = "";

//crear conexion de manera procedural

$conexion = mysqli_connect($db_host,$db_user,$db_pass,$db_name);

//verificar conexion

if(!$conexion){
    die("Conexion fallida: " . mysqli_connect_error());
}


$nombre = $_POST["nombre"];
$apellidoP = $_POST["apellidop"];
$apellidoM = $_POST["apellidom"];
$rut = $_POST["rut"];
$lugar = $_POST["lugar"];
$profesion = $_POST["profesion"];
$fecha = $_POST["fecha"];
$sexo = $_POST["sexo"];
$discap = $_POST["discap"];
$donante = $_POST["donante"];
$nacionalidad = $_POST["Nacionalidad"];

$obj_direccion = "img/";
$obj_archivo = $obj_direccion . basename($_FILES["foto"]["name"]);
move_uploaded_file($_FILES["foto"]["tmp_name"], $obj_archivo);
$foto = mysqli_real_escape_string($conexion, $obj_archivo);

if(!valida_rut($rut)){
    die("Rut erroneo, vuelva a ingresarlo.");
}

guardar($conexion, $nombre, $apellidoP, $apellidoM, $rut, $lugar, $profesion, $fecha, $sexo, $discap, $donante, $foto, $nacionalidad);

//cerrar la conexion
mysqli_close($conexion);

?>
    <form action="index.php" method="POST" enctype="multipart/form-data">
        <input type="submit" value="Ingresar otra persona" class="btn btn-outline-primary">
    </form>
    <form action="lista.php" method="POST" enctype="multipart/form-data">
        <input type="submit" value="Ver personas ingresadas" class="btn btn-outline-primary">
    </form>
</body>
</html>