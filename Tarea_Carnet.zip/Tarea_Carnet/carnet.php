<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <style>
        .fondo {
            background-image: url('img/fondo.png');
            height: 550px;
            width: 850px;
            display: flex;
        }
        .flex{  
            display: flex;
        }
    </style>
</head>

<?php

# datos de conexion a la base de datos

$db_host = "localhost";
$db_name = "registro";
$db_user = "root";
$db_pass = "";

//crear conexion de manera procedural

$conexion = mysqli_connect($db_host,$db_user,$db_pass,$db_name);

//verificar conexion

if(!$conexion){
    die("Conexion fallida: " . mysqli_connect_error());
}

$rut = $_POST["rut"];

$sql = "SELECT * FROM personas WHERE rut='$rut';";
$resultado = $conexion->query($sql);

$aux;

while($col = $resultado->fetch_array()) {
    $aux = $col;
}


?>

<body>
<div class="fondo">
    <div style="height: 550px; width: 50px;"></div>
    <div style="height: 550px; width: 250px;">
        <div style="height: 130px; width: 250px;"></div>
        <div style="height: 300px;width: 220px;"><img src="<?php echo $aux[10]; ?>" style="height: 300px;width: 220px;"></div>
        <div style="height: 40px;width: 250px;"></div>
        <div style="height: 50px;width: 200px; padding-left: 50px;"><h4><?php echo $aux[3]; ?></h4></div>
    </div>
    <div style="height: 550px; width: 190px;">
        <div style="height: 110px;width: 170px;"></div>
        <div style="height: 75px;width: 170px;"><h4><?php echo $aux[1]; ?><br><?php echo $aux[2]; ?></h4></div>
        <div style="height: 50px;width: 200px;"><h4><?php echo $aux[0]; ?></h4></div>
        <div style="height: 55px;width: 170px;"><h4><?php echo $aux[11]; ?></h4></div>
        <div style="height: 50px;width: 170px;"><h4><?php echo $aux[6]; ?></h4></div>
        <div style="height: 50px;width: 170px;"><h4><?php echo date("d/m/Y"); ?></h4></div>
    </div>
    <div style="height: 550px; width: 190px;">
        <div style="height: 110px;width: 170px;"></div>
        <div style="height: 75px;width: 170px;"></h4></div>
        <div style="height: 50px;width: 200px;"></div>
        <div style="height: 55px;width: 170px;"><h4><?php echo $aux[7]; ?></h4></div>
        <div style="height: 50px;width: 170px;"><h4><?php echo rand(1,999999999) ?></h4></div>
        <div style="height: 50px;width: 170px;"><h4><?php echo date("d/m") . "/" .date("Y")+5; ?></h4></div>
    </div>

</div>

<?php
mysqli_close($conexion);



?>